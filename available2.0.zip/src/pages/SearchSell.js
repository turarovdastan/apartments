import React from 'react'

const SearchSell = () => {
  return (
    <div>SearchSell</div>
  )
}

export default SearchSell