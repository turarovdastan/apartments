import React from 'react'
import Navbar from '../components/Navbar';

const searchone = () => {
  return (
    <div>
        <Navbar/>
        
    </div>
  )
}

export default searchone